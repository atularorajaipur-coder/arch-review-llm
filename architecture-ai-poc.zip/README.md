# architecture-ai-poc

Multi-module POC with:
- architecture-mcp-server (Spring Boot MCP tool server)
- architecture-agent (Spring Boot LangGraph4j orchestrator)

See module READMEs for run instructions.
