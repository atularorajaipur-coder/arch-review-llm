package com.poc.mcp.model;

public class MermaidResult {
    public String mermaid;
}
